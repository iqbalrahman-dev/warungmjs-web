<?php

require_once 'database.php';

$tableName = 'users';

$conn = connect_db();

if ($conn) {
    $query = "SELECT * FROM $tableName";
    $data = fetch_data($conn, $query);
    close_db($conn);

    if ($data) {
        header('Content-Type: application/json');
        echo json_encode($data);
    } else {
        header('Content-Type: application/json');
        echo json_encode(array('error' => 'No data found or database error.'));
    }
} else {
    header('Content-Type: application/json');
    echo json_encode(array('error' => 'Failed to connect to the database.'));
}

?>